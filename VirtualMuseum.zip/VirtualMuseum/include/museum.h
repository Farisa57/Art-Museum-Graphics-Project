#ifndef MUSEUM_H
#define MUSEUM_H

#include <glm/glm.hpp>

void initMuseumTextures();

void drawMuseum();

bool nearPainting(
    glm::vec3 pos,
    int& id
);

#endif