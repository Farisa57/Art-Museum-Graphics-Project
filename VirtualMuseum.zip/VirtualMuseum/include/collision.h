#ifndef COLLISION_H
#define COLLISION_H

#include <glm/glm.hpp>

bool checkCollision(
    glm::vec3 position
);

#endif