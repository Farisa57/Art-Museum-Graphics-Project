#ifndef MODEL_H
#define MODEL_H

#include <string>

void loadLibertyModel(
    const std::string& path
);

void loadDogModel(
    const std::string& path
);

void loadLionModel(
    const std::string& path
);

void drawLibertyModel(
    float x,
    float y,
    float z,
    float scale
);

void drawDogModel(
    float x,
    float y,
    float z,
    float scale
);

void drawLionModel(
    float x,
    float y,
    float z,
    float scale
);

#endif