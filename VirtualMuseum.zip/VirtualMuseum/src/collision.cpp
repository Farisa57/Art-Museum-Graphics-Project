#include "../include/collision.h"

bool checkCollision(
    glm::vec3 position
)
{
    float x =
        position.x;

    float z =
        position.z;

    float padding =
        1.0f;

    // Outer museum boundary
    if(
        x < -34 + padding
        ||
        x > 34 - padding
        ||
        z < -19 + padding
        ||
        z > 19 - padding
    )
    {
        return true;
    }

    // LEFT divider wall
    // opening in center
    if(
        x > -16 &&
        x < -14
    )
    {
        if(
            z < -5
            ||
            z > 5
        )
        {
            return true;
        }
    }

    // RIGHT divider wall
    if(
        x > 14 &&
        x < 16
    )
    {
        if(
            z < -5
            ||
            z > 5
        )
        {
            return true;
        }
    }

    // Prevent walking into paintings
    if(
        z < -18.5f
    )
    {
        return true;
    }

    return false;
}