#include "../include/model.h"
#include <GL/glew.h>
#include <GLFW/glfw3.h>
#include <GL/glu.h>

#include <glm/glm.hpp>

#include "../include/camera.h"
#include "../include/museum.h"
#include "../include/collision.h"

#include <iostream>

const unsigned int WIDTH = 1280;
const unsigned int HEIGHT = 720;

Camera camera(glm::vec3(0.0f, 2.0f, 10.0f));

float deltaTime = 0.0f;
float lastFrame = 0.0f;

float lastX = WIDTH / 2.0f;
float lastY = HEIGHT / 2.0f;

bool firstMouse = true;

void mouse_callback(GLFWwindow* window, double xpos, double ypos)
{
    if(firstMouse)
    {
        lastX = xpos;
        lastY = ypos;
        firstMouse = false;
    }

    float xoffset = xpos - lastX;
    float yoffset = lastY - ypos;

    lastX = xpos;
    lastY = ypos;

    camera.ProcessMouseMovement(xoffset, yoffset);
}

void processInput(GLFWwindow* window)
{
    glm::vec3 oldPos = camera.Position;

    if(glfwGetKey(window, GLFW_KEY_W) == GLFW_PRESS)
        camera.ProcessKeyboard(FORWARD, deltaTime);

    if(glfwGetKey(window, GLFW_KEY_S) == GLFW_PRESS)
        camera.ProcessKeyboard(BACKWARD, deltaTime);

    if(glfwGetKey(window, GLFW_KEY_A) == GLFW_PRESS)
        camera.ProcessKeyboard(LEFT, deltaTime);

    if(glfwGetKey(window, GLFW_KEY_D) == GLFW_PRESS)
        camera.ProcessKeyboard(RIGHT, deltaTime);

    if(checkCollision(camera.Position))
        camera.Position = oldPos;

    if(glfwGetKey(window, GLFW_KEY_ESCAPE) == GLFW_PRESS)
        glfwSetWindowShouldClose(window, true);
}

int main()
{
    if(!glfwInit())
    {
        std::cout << "GLFW failed\n";
        return -1;
    }

    GLFWwindow* window = glfwCreateWindow(WIDTH, HEIGHT, "Virtual Museum", NULL, NULL);

    if(!window)
    {
        glfwTerminate();
        return -1;
    }

    glfwMakeContextCurrent(window);

    glfwSetCursorPosCallback(window, mouse_callback);
    glfwSetInputMode(window, GLFW_CURSOR, GLFW_CURSOR_DISABLED);

    glewExperimental = GL_TRUE;

    if(glewInit() != GLEW_OK)
    {
        std::cout << "GLEW failed\n";
        return -1;
    }

glEnable(GL_DEPTH_TEST);
glEnable(GL_TEXTURE_2D);

// ---------- LIGHTING ----------
glEnable(GL_LIGHTING);
GLfloat globalAmbient[] =
{
    0.35f,
    0.35f,
    0.35f,
    1.0f
};

glLightModelfv(
    GL_LIGHT_MODEL_AMBIENT,
    globalAmbient
);
glEnable(GL_LIGHT0);
glEnable(GL_LIGHT1);
glEnable(GL_LIGHT2);
glEnable(GL_LIGHT3);
GLfloat whiteDiffuse[] =
{
    1.0f,
    1.0f,
    1.0f,
    1.0f
};

GLfloat softAmbient[] =
{
    0.25f,
    0.25f,
    0.25f,
    1.0f
};

glLightfv(GL_LIGHT1, GL_DIFFUSE, whiteDiffuse);
glLightfv(GL_LIGHT1, GL_AMBIENT, softAmbient);

glLightfv(GL_LIGHT2, GL_DIFFUSE, whiteDiffuse);
glLightfv(GL_LIGHT2, GL_AMBIENT, softAmbient);

glLightfv(GL_LIGHT3, GL_DIFFUSE, whiteDiffuse);
glLightfv(GL_LIGHT3, GL_AMBIENT, softAmbient);
// smooth shading
glShadeModel(GL_SMOOTH);

// material lighting
glEnable(GL_COLOR_MATERIAL);

glColorMaterial(
    GL_FRONT_AND_BACK,
    GL_AMBIENT_AND_DIFFUSE
);

glEnable(GL_NORMALIZE);
    glPointSize(3.0f);
    
    initMuseumTextures();
    // loadStatueModel("../assets/models/LibertStatue.obj");

    loadLibertyModel(
    "../assets/models/LibertStatue.obj"
);

loadDogModel(
    "../assets/models/13180_ConcreteDogStatue_v1_NEW.obj"
);

loadLionModel(
    "../assets/models/14877_LionSitting_V2.obj"
);

    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    gluPerspective(55.0, (double)WIDTH/HEIGHT, 0.1, 200.0);
    glMatrixMode(GL_MODELVIEW);

    while(!glfwWindowShouldClose(window))
    {
        float currentFrame = glfwGetTime();
        deltaTime = currentFrame - lastFrame;
        lastFrame = currentFrame;

        processInput(window);

        glClearColor(0.08f, 0.08f, 0.10f, 1.0f);
        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

        glLoadIdentity();

        // ===========================
// Main room lighting
// ===========================

GLfloat ambient[] =
{
    0.55f,
    0.55f,
    0.55f,
    1.0f
};

GLfloat diffuse[] =
{
    0.95f,
    0.90f,
    0.80f,
    1.0f
};

GLfloat position0[] =
{
    0.0f,
    6.0f,
    0.0f,
    1.0f
};

glLightfv(
    GL_LIGHT0,
    GL_AMBIENT,
    ambient
);

glLightfv(
    GL_LIGHT0,
    GL_DIFFUSE,
    diffuse
);

glLightfv(
    GL_LIGHT0,
    GL_POSITION,
    position0
);

// ===========================
// Left gallery spotlight
// ===========================

GLfloat leftLight[] =
{
    -20.0f,
    5.5f,
    0.0f,
    1.0f
};

glLightfv(
    GL_LIGHT1,
    GL_POSITION,
    leftLight
);

glLightf(
    GL_LIGHT1,
    GL_SPOT_CUTOFF,
    50.0f
);

// ===========================
// Right gallery spotlight
// ===========================

GLfloat rightLight[] =
{
    20.0f,
    5.5f,
    0.0f,
    1.0f
};

glLightfv(
    GL_LIGHT2,
    GL_POSITION,
    rightLight
);

glLightf(
    GL_LIGHT2,
    GL_SPOT_CUTOFF,
    50.0f
);

// ===========================
// Statue spotlight
// ===========================

GLfloat statueLight[] =
{
    0.0f,
    6.0f,
    -5.0f,
    1.0f
};

glLightfv(
    GL_LIGHT3,
    GL_POSITION,
    statueLight
);

glLightf(
    GL_LIGHT3,
    GL_SPOT_CUTOFF,
    40.0f
);

        glm::vec3 center = camera.Position + camera.Front;

        gluLookAt(
            camera.Position.x, camera.Position.y, camera.Position.z,
            center.x, center.y, center.z,
            0.0f, 1.0f, 0.0f
        );

        drawMuseum();
        drawLibertyModel(
    0.0f,
    0.0f,
    -5.0f,
    3.0f
);

drawDogModel(
    -15.0f,
    0.0f,
    0.0f,
    0.1f
);

drawLionModel(
    15.0f,
    0.0f,
    0.0f,
    0.2f
);

        int paintingID = -1;

        if(nearPainting(camera.Position, paintingID))
        {
            if(glfwGetKey(window, GLFW_KEY_E) == GLFW_PRESS)
            {
                const char* title = "Artwork";

                switch(paintingID)
                {
                    case 0: title = "Mona Lisa"; break;
                    case 1: title = "Starry Night"; break;
                    case 2: title = "The Scream"; break;
                    case 3: title = "The Last Supper"; break;
                    case 4: title = "Abstract Art"; break;
                    case 5: title = "Digital Art"; break;
                }

                glfwSetWindowTitle(window, title);
            }
        }
        else
        {
            glfwSetWindowTitle(window, "Virtual Museum");
        }

        glfwSwapBuffers(window);
        glfwPollEvents();
    }

    glfwTerminate();
    return 0;
}