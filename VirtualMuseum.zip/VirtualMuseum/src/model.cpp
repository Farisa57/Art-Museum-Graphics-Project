#include "../include/model.h"

#include <assimp/Importer.hpp>
#include <assimp/postprocess.h>
#include <assimp/scene.h>

#include <GL/glew.h>

#include <iostream>
#include <vector>

struct TriangleVertex
{
    float x, y, z;
};

std::vector<TriangleVertex> libertyVertices;
std::vector<TriangleVertex> dogVertices;
std::vector<TriangleVertex> lionVertices;

void processMesh(
    aiMesh* mesh,
    std::vector<TriangleVertex>& vertices
)
{
    for(unsigned int i = 0; i < mesh->mNumFaces; i++)
    {
        aiFace face = mesh->mFaces[i];

        if(face.mNumIndices != 3)
            continue;

        for(unsigned int j = 0; j < 3; j++)
        {
            unsigned int index =
                face.mIndices[j];

            TriangleVertex v;

            v.x = mesh->mVertices[index].x;
            v.y = mesh->mVertices[index].y;
            v.z = mesh->mVertices[index].z;

            vertices.push_back(v);
        }
    }
}

void processNode(
    aiNode* node,
    const aiScene* scene,
    std::vector<TriangleVertex>& vertices
)
{
    for(unsigned int i = 0;
        i < node->mNumMeshes;
        i++)
    {
        aiMesh* mesh =
            scene->mMeshes[
                node->mMeshes[i]
            ];

        processMesh(
            mesh,
            vertices
        );
    }

    for(unsigned int i = 0;
        i < node->mNumChildren;
        i++)
    {
        processNode(
            node->mChildren[i],
            scene,
            vertices
        );
    }
}

void loadModel(
    const std::string& path,
    std::vector<TriangleVertex>& vertices
)
{
    Assimp::Importer importer;

    const aiScene* scene =
        importer.ReadFile(
            path,
            aiProcess_Triangulate |
            aiProcess_JoinIdenticalVertices
        );

    if(!scene || !scene->mRootNode)
    {
        std::cout
            << "Assimp Error: "
            << importer.GetErrorString()
            << std::endl;

        return;
    }

    vertices.clear();

    processNode(
        scene->mRootNode,
        scene,
        vertices
    );

    std::cout
        << "Loaded "
        << vertices.size()
        << " vertices\n";
}

void loadLibertyModel(
    const std::string& path
)
{
    loadModel(
        path,
        libertyVertices
    );
}

void loadDogModel(
    const std::string& path
)
{
    loadModel(
        path,
        dogVertices
    );
}

void loadLionModel(
    const std::string& path
)
{
    loadModel(
        path,
        lionVertices
    );
}

void drawModel(
    std::vector<TriangleVertex>& vertices,
    float x,
    float y,
    float z,
    float scale
)
{
    glPushMatrix();

    glTranslatef(
        x,
        y + 0.3f,
        z
    );

    glRotatef(
        90.0f,
        0.0f,
        1.0f,
        0.0f
    );

    glScalef(
        scale,
        scale,
        scale
    );

    glColor3f(0.08f, 0.08f, 0.08f);

    glPolygonMode(
        GL_FRONT_AND_BACK,
        GL_FILL
    );

    glBegin(GL_TRIANGLES);

    for(const auto& v : vertices)
    {
        glVertex3f(
            v.x,
            v.y,
            v.z
        );
    }

    glEnd();

    glPopMatrix();
}

void drawLibertyModel(
    float x,
    float y,
    float z,
    float scale
)
{
    drawModel(
        libertyVertices,
        x,
        y,
        z,
        scale
    );
}

void drawDogModel(
    float x,
    float y,
    float z,
    float scale
)
{
    glPushMatrix();

    glTranslatef(x, y, z);

    glRotatef(
        -90.0f,
        1.0f,
        0.0f,
        0.0f
    );

    glScalef(scale, scale, scale);

    glColor3f(0.08f, 0.08f, 0.08f);

    glBegin(GL_TRIANGLES);

    for(const auto& v : dogVertices)
    {
        glVertex3f(v.x, v.y, v.z);
    }

    glEnd();

    glPopMatrix();
}

void drawLionModel(
    float x,
    float y,
    float z,
    float scale
)
{
    glPushMatrix();

    glTranslatef(x, y, z);

    glRotatef(
        -90.0f,
        1.0f,
        0.0f,
        0.0f
    );

    glScalef(scale, scale, scale);

    glColor3f(
    0.05f,
    0.05f,
    0.05f
);
    glBegin(GL_TRIANGLES);

    for(const auto& v : lionVertices)
    {
        glVertex3f(v.x, v.y, v.z);
    }

    glEnd();

    glPopMatrix();
}