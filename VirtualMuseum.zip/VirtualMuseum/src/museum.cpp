#include "../include/model.h"
#include "../include/museum.h"
#include "../include/stb_image.h"

#include <GL/glew.h>
#include <GL/glu.h>
#include <glm/glm.hpp>

#include <iostream>
#include <cmath>

GLuint paintingTextures[6];

struct Painting
{
    float x,y,z;
};

Painting paintings[] =
{
    {-10,2.5,-18},
    { 10,2.5,-18},
    {-34,2.5,-8},
    {-34,2.5, 8},
    { 34,2.5,-8},
    { 34,2.5, 8}
};

GLuint loadTexture(const char* path)
{
    GLuint tex;
    glGenTextures(1, &tex);

    int w,h,n;

    stbi_set_flip_vertically_on_load(true);

    unsigned char* data = stbi_load(path, &w,&h,&n,0);

    if(!data)
    {
        std::cout << "Texture failed: " << path << std::endl;
        return 0;
    }

    glBindTexture(GL_TEXTURE_2D, tex);

    glPixelStorei(GL_UNPACK_ALIGNMENT, 1);

    GLenum format = (n == 4) ? GL_RGBA : GL_RGB;

    glTexImage2D(GL_TEXTURE_2D,0,format,w,h,0,format,GL_UNSIGNED_BYTE,data);

    glGenerateMipmap(GL_TEXTURE_2D);

    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

    stbi_image_free(data);

    return tex;
}

void initMuseumTextures()
{
    paintingTextures[0]=loadTexture("../assets/paintings/monalisa.jpg");
    paintingTextures[1]=loadTexture("../assets/paintings/starrynight.jpg");
    paintingTextures[2]=loadTexture("../assets/paintings/scream.jpg");
    paintingTextures[3]=loadTexture("../assets/paintings/lastsupper.jpg");
    paintingTextures[4]=loadTexture("../assets/paintings/art1.jpg");
    paintingTextures[5]=loadTexture("../assets/paintings/art2.jpg");
    paintingTextures[6]=loadTexture("../assets/paintings/art3.jpg");
    paintingTextures[7]=loadTexture("../assets/paintings/art4.jpg");
}

void drawPainting(int id,float x,float y,float z,bool rot)
{
    glEnable(GL_TEXTURE_2D);
    glBindTexture(GL_TEXTURE_2D, paintingTextures[id]);

    glColor3f(1,1,1);

    glPushMatrix();
    glTranslatef(x,y,z);

    if(rot) glRotatef(90,0,1,0);

    glBegin(GL_QUADS);

    glTexCoord2f(0,0); glVertex3f(-2,-1.5,0);
    glTexCoord2f(1,0); glVertex3f( 2,-1.5,0);
    glTexCoord2f(1,1); glVertex3f( 2, 1.5,0);
    glTexCoord2f(0,1); glVertex3f(-2, 1.5,0);

    glEnd();

    glPopMatrix();
    glDisable(GL_TEXTURE_2D);
}

void drawStatue(float x,float z)
{
    GLUquadric* q = gluNewQuadric();

    glColor3f(0.7,0.7,0.7);

    glPushMatrix();
    glTranslatef(x,0.5,z);

    gluCylinder(q,0.5,0.5,2.0,30,30);

    glTranslatef(0,0,2.0);
    gluSphere(q,0.6,30,30);

    glPopMatrix();

    gluDeleteQuadric(q);
}

bool nearPainting(glm::vec3 pos,int& id)
{
    for(int i=0;i<6;i++)
    {
        float dx = pos.x - paintings[i].x;
        float dz = pos.z - paintings[i].z;

        if(sqrt(dx*dx + dz*dz) < 7.0f)
        {
            id = i;
            return true;
        }
    }
    return false;
}

void drawMuseum()
{
    // Black and White Tile Floor

float tileSize = 2.0f;

for(float x = -35.0f; x < 35.0f; x += tileSize)
{
    for(float z = -20.0f; z < 20.0f; z += tileSize)
    {
        int checker =
            ((int)((x + 35) / tileSize) +
             (int)((z + 20) / tileSize)) % 2;

        if(checker == 0)
            glColor3f(1.0f, 1.0f, 1.0f); // White
        else
            glColor3f(0.0f, 0.0f, 0.0f); // Black

        glBegin(GL_QUADS);
        glVertex3f(x,            0.0f, z);
        glVertex3f(x + tileSize, 0.0f, z);
        glVertex3f(x + tileSize, 0.0f, z + tileSize);
        glVertex3f(x,            0.0f, z + tileSize);
        glEnd();
    }
}
    // =====================================
// MARBLE PANEL WALLS
// =====================================

float panelWidth = 5.0f;
float panelHeight = 1.75f;

// BACK WALL
for(float x = -35; x < 35; x += panelWidth)
{
    for(float y = 0; y < 7; y += panelHeight)
    {
        if((((int)(x/panelWidth)) + ((int)(y/panelHeight))) % 2 == 0)
            glColor3f(0.97f, 0.97f, 0.95f);
        else
            glColor3f(0.90f, 0.90f, 0.88f);

        glBegin(GL_QUADS);
        glVertex3f(x, y, -20);
        glVertex3f(x + panelWidth, y, -20);
        glVertex3f(x + panelWidth, y + panelHeight, -20);
        glVertex3f(x, y + panelHeight, -20);
        glEnd();
    }
}

// FRONT WALL
for(float x = -35; x < 35; x += panelWidth)
{
    for(float y = 0; y < 7; y += panelHeight)
    {
        if((((int)(x/panelWidth)) + ((int)(y/panelHeight))) % 2 == 0)
            glColor3f(0.97f, 0.97f, 0.95f);
        else
            glColor3f(0.90f, 0.90f, 0.88f);

        glBegin(GL_QUADS);
        glVertex3f(x, y, 20);
        glVertex3f(x + panelWidth, y, 20);
        glVertex3f(x + panelWidth, y + panelHeight, 20);
        glVertex3f(x, y + panelHeight, 20);
        glEnd();
    }
}

// LEFT WALL
for(float z = -20; z < 20; z += panelWidth)
{
    for(float y = 0; y < 7; y += panelHeight)
    {
        if((((int)(z/panelWidth)) + ((int)(y/panelHeight))) % 2 == 0)
            glColor3f(0.97f, 0.97f, 0.95f);
        else
            glColor3f(0.90f, 0.90f, 0.88f);

        glBegin(GL_QUADS);
        glVertex3f(-35, y, z);
        glVertex3f(-35, y, z + panelWidth);
        glVertex3f(-35, y + panelHeight, z + panelWidth);
        glVertex3f(-35, y + panelHeight, z);
        glEnd();
    }
}

// RIGHT WALL
for(float z = -20; z < 20; z += panelWidth)
{
    for(float y = 0; y < 7; y += panelHeight)
    {
        if((((int)(z/panelWidth)) + ((int)(y/panelHeight))) % 2 == 0)
            glColor3f(0.97f, 0.97f, 0.95f);
        else
            glColor3f(0.90f, 0.90f, 0.88f);

        glBegin(GL_QUADS);
        glVertex3f(35, y, z);
        glVertex3f(35, y, z + panelWidth);
        glVertex3f(35, y + panelHeight, z + panelWidth);
        glVertex3f(35, y + panelHeight, z);
        glEnd();
    }
}

glColor3f(0.75f, 0.75f, 0.75f);
glLineWidth(2.0f);

glBegin(GL_LINES);

// Back wall vertical seams
for(float x=-35; x<=35; x+=5)
{
    glVertex3f(x,0,-19.95f);
    glVertex3f(x,7,-19.95f);
}

// Back wall horizontal seams
for(float y=0; y<=7; y+=1.75f)
{
    glVertex3f(-35,y,-19.95f);
    glVertex3f(35,y,-19.95f);
}

glEnd();
// Main Ceiling
glColor3f(0.10f,0.10f,0.12f);

glBegin(GL_QUADS);
glVertex3f(-35,7,-20);
glVertex3f(35,7,-20);
glVertex3f(35,7,20);
glVertex3f(-35,7,20);
glEnd();


// Ceiling Grid Lines
glColor3f(0.25f,0.25f,0.28f);
glLineWidth(3.0f);

glBegin(GL_LINES);

// Vertical ceiling lines
for(float x=-30; x<=30; x+=10)
{
    glVertex3f(x,6.99f,-20);
    glVertex3f(x,6.99f,20);
}

// Horizontal ceiling lines
for(float z=-15; z<=15; z+=10)
{
    glVertex3f(-35,6.99f,z);
    glVertex3f(35,6.99f,z);
}

glEnd();

    // paintings
    drawPainting(0,-10,3,-19.8,false);
    drawPainting(1,10,3,-19.8,false);
    drawPainting(2,-34,3,-8,true);
    drawPainting(3,-34,3,8,true);
    drawPainting(4,34,3,-8,true);
    drawPainting(5,34,3,8,true);
    drawPainting(6,-10,3,19.8,false);
    drawPainting(7,10,3,19.8,false);

    // statues
    // drawStatueModel(0.0f,0.0f,-5.0f,3.0f);
}